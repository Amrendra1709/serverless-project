export interface TodoUpdate {
  name: string
  dueDate: string
  done: boolean
}
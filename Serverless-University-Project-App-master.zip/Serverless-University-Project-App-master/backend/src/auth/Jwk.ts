import {Jwks} from "./JwksPayload";

export interface JWKS {
    keys: Jwks []
}